package poo;

import uni1a.*;

public class PruebaAudioVisual {
    public static void main(String[] args) {

        System.out.println("=== SISTEMA DE CONTENIDO AUDIOVISUAL ===\n");

        // 1. PELICULA + ACTORES (ASOCIACION)
        System.out.println("--- ASOCIACION: Pelicula con Actores ---");
        Actor actor1 = new Actor("Tom Hanks", "Estadounidense", 1956, "Protagonista");
        Actor actor2 = new Actor("Robin Wright", "Estadounidense", 1966, "Secundario");

        Pelicula pelicula1 = new Pelicula("Forrest Gump", 142, "Drama", "Paramount");
        pelicula1.agregarActor(actor1);
        pelicula1.agregarActor(actor2);
        pelicula1.mostrarDetalles();

        // 2. SERIE DE TV + TEMPORADAS (COMPOSICION)
        System.out.println("--- COMPOSICION: Serie con Temporadas ---");
        SerieDeTV serie1 = new SerieDeTV("Breaking Bad", 47, "Drama", 5);
        serie1.agregarTemporada(7,  2008, "Walter White empieza su transformacion");
        serie1.agregarTemporada(13, 2009, "El Imperio de Heisenberg crece");
        serie1.agregarTemporada(13, 2010, "Guerra con los Salamanca");
        serie1.mostrarDetalles();

        // 3. DOCUMENTAL + INVESTIGADORES (AGREGACION)
        System.out.println("--- AGREGACION: Documental con Investigadores ---");
        Investigador inv1 = new Investigador("Jane Goodall", "Instituto Jane Goodall", "Primates", 60);
        Investigador inv2 = new Investigador("David Attenborough", "BBC", "Zoologia", 70);

        Documental doc1 = new Documental("Planet Earth II", 60, "Naturaleza", "Vida Salvaje");
        doc1.agregarInvestigador(inv1);
        doc1.agregarInvestigador(inv2);
        doc1.mostrarDetalles();

        // 4. VIDEO YOUTUBE (nueva subclase)
        System.out.println("--- NUEVA SUBCLASE: VideoYouTube ---");
        VideoYouTube video1 = new VideoYouTube("Baby Shark", 2, "Infantil", "Pinkfong", 13000000000L, 15000000, true);
        video1.mostrarDetalles();

        // 5. CORTOMETRAJE (nueva subclase)
        System.out.println("--- NUEVA SUBCLASE: Cortometraje ---");
        Cortometraje corto1 = new Cortometraje("La Noche del Faro", 18, "Drama", "Ana Garcia", "Festival de Cannes", true, "Ficcion", 5000);
        corto1.mostrarDetalles();

        // Array original con todas las clases
        System.out.println("--- ARRAY DE CONTENIDOS ---");
        ContenidoAudiovisual[] contenidos = new ContenidoAudiovisual[5];
        contenidos[0] = new Pelicula("Avatar", 125, "Accion", "20th Century Studios");
        contenidos[1] = new SerieDeTV("Game of Thrones", 60, "Fantasy", 8);
        contenidos[2] = new Documental("Cosmos", 45, "Ciencia", "Astronomy");
        contenidos[3] = new VideoYouTube("Tutorial Java", 30, "Educativo", "DevCanal", 500000, 20000, false);
        contenidos[4] = new Cortometraje("El Puente", 15, "Drama", "Luis Torres", "Sundance", false, "Experimental", 800);

        for (ContenidoAudiovisual contenido : contenidos) {
            contenido.mostrarDetalles();
        }
    }
}