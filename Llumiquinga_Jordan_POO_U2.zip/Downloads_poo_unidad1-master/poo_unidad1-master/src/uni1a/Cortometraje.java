package uni1a;

public class Cortometraje extends ContenidoAudiovisual {

    private String director;
    private String festival;
    private boolean ganoPremio;
    private String tipoCortometraje;
    private int presupuesto;

    public Cortometraje(String titulo, int duracionEnMinutos, String genero,
                        String director, String festival, boolean ganoPremio,
                        String tipoCortometraje, int presupuesto) {
        super(titulo, duracionEnMinutos, genero);
        this.director = director;
        this.festival = festival;
        this.ganoPremio = ganoPremio;
        this.tipoCortometraje = tipoCortometraje;
        this.presupuesto = presupuesto;
    }

    public boolean esIndie() { return presupuesto < 10000; }

    public String descripcionProduccion() {
        if (presupuesto < 1000)   return "Micro-presupuesto";
        if (presupuesto < 10000)  return "Indie";
        if (presupuesto < 100000) return "Semi-profesional";
        return "Profesional";
    }

    @Override
    public void mostrarDetalles() {
        System.out.println("=== CORTOMETRAJE ===");
        System.out.println("Titulo: " + getTitulo());
        System.out.println("  Director: " + director);
        System.out.println("  Tipo: " + tipoCortometraje);
        System.out.println("  Festival: " + festival);
        System.out.println("  Premio: " + (ganoPremio ? "Si gano premio" : "Sin premio"));
        System.out.println("  Presupuesto: $" + presupuesto);
        System.out.println("  Produccion: " + descripcionProduccion());
    }

    public String getDirector() { return director; }
    public void setDirector(String director) { this.director = director; }

    public String getFestival() { return festival; }
    public void setFestival(String festival) { this.festival = festival; }

    public boolean isGanoPremio() { return ganoPremio; }
    public void setGanoPremio(boolean ganoPremio) { this.ganoPremio = ganoPremio; }

    public String getTipoCortometraje() { return tipoCortometraje; }
    public void setTipoCortometraje(String t) { this.tipoCortometraje = t; }

    public int getPresupuesto() { return presupuesto; }
    public void setPresupuesto(int presupuesto) { this.presupuesto = presupuesto; }
}