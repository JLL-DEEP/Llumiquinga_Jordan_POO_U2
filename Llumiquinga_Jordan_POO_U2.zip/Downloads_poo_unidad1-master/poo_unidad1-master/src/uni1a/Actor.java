package uni1a;

public class Actor {

    private String nombre;
    private String nacionalidad;
    private int anioNacimiento;
    private String rolPrincipal;

    public Actor(String nombre, String nacionalidad, int anioNacimiento, String rolPrincipal) {
        this.nombre = nombre;
        this.nacionalidad = nacionalidad;
        this.anioNacimiento = anioNacimiento;
        this.rolPrincipal = rolPrincipal;
    }

    public void mostrarInfo() {
        System.out.println("  Actor: " + nombre +
                " | Nacionalidad: " + nacionalidad +
                " | Nacimiento: " + anioNacimiento +
                " | Rol: " + rolPrincipal);
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getNacionalidad() { return nacionalidad; }
    public void setNacionalidad(String nacionalidad) { this.nacionalidad = nacionalidad; }

    public int getAnioNacimiento() { return anioNacimiento; }
    public void setAnioNacimiento(int anioNacimiento) { this.anioNacimiento = anioNacimiento; }

    public String getRolPrincipal() { return rolPrincipal; }
    public void setRolPrincipal(String rolPrincipal) { this.rolPrincipal = rolPrincipal; }

    @Override
    public String toString() {
        return nombre + " (" + rolPrincipal + ")";
    }
}