package uni1a;

public class VideoYouTube extends ContenidoAudiovisual {

    private String canal;
    private long vistas;
    private int likes;
    private boolean esMonetizado;

    public VideoYouTube(String titulo, int duracionEnMinutos, String genero,
                        String canal, long vistas, int likes, boolean esMonetizado) {
        super(titulo, duracionEnMinutos, genero);
        this.canal = canal;
        this.vistas = vistas;
        this.likes = likes;
        this.esMonetizado = esMonetizado;
    }

    public double calcularRatioLikes() {
        if (vistas == 0) return 0;
        return ((double) likes / vistas) * 100;
    }

    public String clasificarPorVistas() {
        if (vistas >= 1000000000) return "Viral Historico (1B+)";
        if (vistas >= 100000000)  return "Mega Viral (100M+)";
        if (vistas >= 1000000)    return "Viral (1M+)";
        if (vistas >= 100000)     return "Popular (100K+)";
        return "En crecimiento";
    }

    @Override
    public void mostrarDetalles() {
        System.out.println("=== VIDEO DE YOUTUBE ===");
        System.out.println("Titulo: " + getTitulo());
        System.out.println("  Canal: " + canal);
        System.out.println("  Vistas: " + vistas);
        System.out.println("  Likes: " + likes);
        System.out.println("  Ratio Likes: " + calcularRatioLikes() + "%");
        System.out.println("  Clasificacion: " + clasificarPorVistas());
        System.out.println("  Monetizado: " + (esMonetizado ? "Si" : "No"));
    }

    public String getCanal() { return canal; }
    public void setCanal(String canal) { this.canal = canal; }

    public long getVistas() { return vistas; }
    public void setVistas(long vistas) { this.vistas = vistas; }

    public int getLikes() { return likes; }
    public void setLikes(int likes) { this.likes = likes; }

    public boolean isEsMonetizado() { return esMonetizado; }
    public void setEsMonetizado(boolean esMonetizado) { this.esMonetizado = esMonetizado; }
}