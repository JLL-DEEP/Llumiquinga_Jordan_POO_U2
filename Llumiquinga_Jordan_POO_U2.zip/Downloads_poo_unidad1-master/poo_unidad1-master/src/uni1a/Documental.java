package uni1a;

import java.util.ArrayList;
import java.util.List;

// SubClase Documental que extiende de ContenidoAudiovisual
public class Documental extends ContenidoAudiovisual {

    private String tema;

    // AGREGACION: los investigadores existen independientemente
    // Un investigador puede estar en varios documentales
    private List<Investigador> investigadores;

    public Documental(String titulo, int duracionEnMinutos, String genero, String tema) {
        super(titulo, duracionEnMinutos, genero);
        this.tema = tema;
        this.investigadores = new ArrayList<>();
    }

    // Agregar investigador (agregacion: ya existe afuera)
    public void agregarInvestigador(Investigador investigador) {
        investigadores.add(investigador);
    }

    public void removerInvestigador(Investigador investigador) {
        investigadores.remove(investigador);
    }

    public String getTema() { return tema; }
    public void setTema(String tema) { this.tema = tema; }

    public List<Investigador> getInvestigadores() { return investigadores; }

    @Override
    public void mostrarDetalles() {
        System.out.println("Detalles del documental:");
        System.out.println("ID: " + getId());
        System.out.println("Titulo: " + getTitulo());
        System.out.println("Duracion en minutos: " + getDuracionEnMinutos());
        System.out.println("Genero: " + getGenero());
        System.out.println("Tema: " + tema);
        if (!investigadores.isEmpty()) {
            System.out.println("Investigadores (" + investigadores.size() + "):");
            for (Investigador i : investigadores) {
                i.mostrarInfo();
            }
        }
        System.out.println();
    }
}