package uni1a;

public class Temporada {

    private int numeroTemporada;
    private int cantidadEpisodios;
    private int anioEmision;
    private String descripcion;

    public Temporada(int numeroTemporada, int cantidadEpisodios,
                     int anioEmision, String descripcion) {
        this.numeroTemporada = numeroTemporada;
        this.cantidadEpisodios = cantidadEpisodios;
        this.anioEmision = anioEmision;
        this.descripcion = descripcion;
    }

    public void mostrarInfo() {
        System.out.println("  Temporada " + numeroTemporada +
                " | Episodios: " + cantidadEpisodios +
                " | Emisión: " + anioEmision +
                " | " + descripcion);
    }

    public int getNumeroTemporada() { return numeroTemporada; }
    public void setNumeroTemporada(int n) { this.numeroTemporada = n; }

    public int getCantidadEpisodios() { return cantidadEpisodios; }
    public void setCantidadEpisodios(int c) { this.cantidadEpisodios = c; }

    public int getAnioEmision() { return anioEmision; }
    public void setAnioEmision(int a) { this.anioEmision = a; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String d) { this.descripcion = d; }

    @Override
    public String toString() {
        return "Temporada " + numeroTemporada + " (" + cantidadEpisodios + " eps, " + anioEmision + ")";
    }
}