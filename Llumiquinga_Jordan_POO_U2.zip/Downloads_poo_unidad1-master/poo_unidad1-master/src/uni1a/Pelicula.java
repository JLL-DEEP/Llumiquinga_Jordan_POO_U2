package uni1a;

import java.util.ArrayList;
import java.util.List;

// SubClase Pelicula que extiende de ContenidoAudiovisual
public class Pelicula extends ContenidoAudiovisual {

    private String estudio;

    // ASOCIACION: La pelicula tiene una lista de actores
    // Los actores existen independientemente de la pelicula
    private List<Actor> actores;

    public Pelicula(String titulo, int duracionEnMinutos, String genero, String estudio) {
        super(titulo, duracionEnMinutos, genero);
        this.estudio = estudio;
        this.actores = new ArrayList<>();
    }

    // Agregar actor (asociacion: el actor ya existe afuera)
    public void agregarActor(Actor actor) {
        actores.add(actor);
    }

    public void removerActor(Actor actor) {
        actores.remove(actor);
    }

    public String getEstudio() {
        return estudio;
    }

    public void setEstudio(String estudio) {
        this.estudio = estudio;
    }

    public List<Actor> getActores() {
        return actores;
    }

    @Override
    public void mostrarDetalles() {
        System.out.println("Detalles de la pelicula:");
        System.out.println("ID: " + getId());
        System.out.println("Titulo: " + getTitulo());
        System.out.println("Duracion en minutos: " + getDuracionEnMinutos());
        System.out.println("Genero: " + getGenero());
        System.out.println("Estudio: " + estudio);
        if (!actores.isEmpty()) {
            System.out.println("Actores (" + actores.size() + "):");
            for (Actor a : actores) {
                a.mostrarInfo();
            }
        }
        System.out.println();
    }
}