package uni1a;

public class Investigador {

    private String nombre;
    private String institucion;
    private String areaEspecializacion;
    private int aniosExperiencia;

    public Investigador(String nombre, String institucion,
                        String areaEspecializacion, int aniosExperiencia) {
        this.nombre = nombre;
        this.institucion = institucion;
        this.areaEspecializacion = areaEspecializacion;
        this.aniosExperiencia = aniosExperiencia;
    }

    public void mostrarInfo() {
        System.out.println("  Investigador: " + nombre +
                " | Institución: " + institucion +
                " | Área: " + areaEspecializacion +
                " | Experiencia: " + aniosExperiencia + " años");
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getInstitucion() { return institucion; }
    public void setInstitucion(String institucion) { this.institucion = institucion; }

    public String getAreaEspecializacion() { return areaEspecializacion; }
    public void setAreaEspecializacion(String area) { this.areaEspecializacion = area; }

    public int getAniosExperiencia() { return aniosExperiencia; }
    public void setAniosExperiencia(int a) { this.aniosExperiencia = a; }

    @Override
    public String toString() {
        return nombre + " - " + areaEspecializacion;
    }
}