package uni1a;

import java.util.ArrayList;
import java.util.List;

// SubClase SerieDeTV que extiende de ContenidoAudiovisual
public class SerieDeTV extends ContenidoAudiovisual {

    private int temporadasCount;

    // COMPOSICION: las temporadas se crean DENTRO de la serie
    // Si la serie desaparece, las temporadas tambien
    private List<Temporada> temporadas;

    public SerieDeTV(String titulo, int duracionEnMinutos, String genero, int temporadasCount) {
        super(titulo, duracionEnMinutos, genero);
        this.temporadasCount = temporadasCount;
        this.temporadas = new ArrayList<>();
    }

    // Las temporadas nacen dentro de la serie (composicion)
    public void agregarTemporada(int cantidadEpisodios, int anioEmision, String descripcion) {
        int numero = temporadas.size() + 1;
        Temporada nueva = new Temporada(numero, cantidadEpisodios, anioEmision, descripcion);
        temporadas.add(nueva);
    }

    public int getTotalEpisodios() {
        int total = 0;
        for (Temporada t : temporadas) {
            total += t.getCantidadEpisodios();
        }
        return total;
    }

    public int getTemporadasCount() { return temporadasCount; }
    public void setTemporadasCount(int temporadasCount) { this.temporadasCount = temporadasCount; }

    public List<Temporada> getTemporadas() { return temporadas; }

    @Override
    public void mostrarDetalles() {
        System.out.println("Detalles de la serie:");
        System.out.println("ID: " + getId());
        System.out.println("Titulo: " + getTitulo());
        System.out.println("Duracion en minutos: " + getDuracionEnMinutos());
        System.out.println("Genero: " + getGenero());
        System.out.println("Temporadas: " + temporadasCount);
        System.out.println("Total episodios: " + getTotalEpisodios());
        if (!temporadas.isEmpty()) {
            System.out.println("Detalle temporadas:");
            for (Temporada t : temporadas) {
                t.mostrarInfo();
            }
        }
        System.out.println();
    }
}